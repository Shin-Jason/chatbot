# Insert your TOGETHER_API_KEY and remove '.example' from the file name 
TOGETHER_API_KEY="dfc95e57a6299157a7bdff7338cd443702403b122bc307f0b5ed8d73a191d7e2"